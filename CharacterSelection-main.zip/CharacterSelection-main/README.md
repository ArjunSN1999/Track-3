# CharacterSelection
This is the project which demonstrates how character selection works in actual games.
